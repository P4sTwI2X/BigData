# Some note:
## Input folder: Using bbc folder
## Run command:
- bin/hadoop App.jar App <input/path> <output/path> -skip <path/to/stopwords/file>
## output:
- The output file will be named task_1_1-r-00000
