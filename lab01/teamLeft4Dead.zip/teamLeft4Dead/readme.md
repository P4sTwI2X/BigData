# CSC14118 _ Introduction to Big Data/Lab 01: Gentle introduction to Hadoop.

This is the file repository for lab 01 of Big Data group: Left4Dead.\
\
21127329 - Châu Tấn Kiệt (KHMT2)\
21127170 - Nguyễn Thế Thiện (KHMT1)\
21127642 - Trịnh Minh Long (KHMT1)\
\
Teacher in charge: Đỗ Trọng Lễ, Bùi Huỳnh Trung Nam.\
\
Notes to instructors: none.\
